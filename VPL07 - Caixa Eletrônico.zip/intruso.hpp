#include <string>

class Intruso{
    /*Continue a implementação da classe Intruso*/

    public:
        void set_senha_vazada(std::string vazou);
        std::string crack_senha();
};